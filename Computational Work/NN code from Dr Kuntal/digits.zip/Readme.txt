Run NN for setting the weights / Training of network 
Run NN_test for checking the network with Test cases.